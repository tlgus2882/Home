import pygame
import sys
import random
import tkinter as tk
from tkinter import *
import tkinter.messagebox
from PIL import ImageTk, Image
from tkinter import simpledialog



# 화면 설정
SCREEN_WIDTH, SCREEN_HEIGHT = 1280, 720
pygame.init()
pygame.mixer.init()
clock = pygame.time.Clock()
FPS = 60
sleep = False
# 전역 변수
player_money = 100
knowledge = 0
screen_image_y = 585
grade = 0

# 이미지 및 음악 로드
screen_image = pygame.image.load("screenimage.png")
screen_image = pygame.transform.scale(screen_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.mixer.music.load("background_music.mp3")
pygame.mixer.music.set_volume(0.3)
pygame.mixer.music.play(-1)
button_click_sound = pygame.mixer.Sound("button04a.mp3")
button_click_sound.set_volume(0.7)

SCREEN = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
font = pygame.font.Font(None, 36)

class Animated(pygame.sprite.Sprite):
    def __init__(self, position):
        super().__init__()
        size = (100, 80)
        self.front_images = [
            pygame.image.load("front1.png"),
            pygame.image.load("front2.png"),
            pygame.image.load("front3.png")
        ]
        self.right_images = [
            pygame.image.load("right1.png"),
            pygame.image.load("right2.png"),
            pygame.image.load("right3.png")
        ]
        self.left_images = [pygame.transform.flip(img, True, False) for img in self.right_images]
        self.rect = pygame.Rect(position, size)
        self.images = [pygame.transform.scale(img, size) for img in self.front_images]
        self.direction = 'front'
        self.state = 0
        self.index = 0
        self.image = self.images[self.index]
        self.animation_time = 0.1
        self.current_time = 0
        self.speed_x = 0

    def update(self, mt):
        if self.direction == 'front':
            self.images = self.front_images
        elif self.direction == 'right':
            self.images = self.right_images
            self.speed_x = 4
        elif self.direction == 'left':
            self.images = self.left_images
            self.speed_x = -4

        self.current_time += mt
        if self.current_time >= self.animation_time:
            self.current_time = 0
            self.index = (self.index + 1) % len(self.images)
            self.image = pygame.transform.scale(self.images[self.index], (100, 80))
        self.rect.x += self.speed_x

        # 화면 경계 확인
        if self.rect.left < 0:
            self.rect.left = 0
        elif self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH

def game_shop():
    root = tk.Tk()
    root.geometry("480x480")
    def msg_Box1():
        tk.messagebox.showinfo("구매실패","돈이 없습니다.")
    def msg_Box2():
        tk.messagebox.showinfo("구매실패","지능이 모자랍니다.")
    def close():
        root.destroy()        
    def buy_Grade():
        global grade
        global player_money
        global knowledge
        if player_money >= 100 and knowledge >= 10:
            player_money -= 100
            grade += 1
        elif player_money < 100:
            msg_Box1()
        elif knowledge < 10:
            msg_Box2()
        root.destroy()
    def buy_Grade3():
        global grade
        global player_money
        global knowledge
        if player_money >= 250 and knowledge >= 20:
            player_money -= 250
            grade += 3
        elif player_money < 250:
            msg_Box1()
        elif knowledge < 20:
            msg_Box2()
        root.destroy()
    def buy_Grade10():
        global grade
        global player_money
        global knowledge
        if player_money >= 700 and knowledge >= 50:
            player_money -= 700
            grade += 10
        elif player_money < 700:
            msg_Box1()
        elif knowledge < 50:
            msg_Box2()
        root.destroy()
    
    btn = Button(root,width=40,height=5,bg="grey", text="인공지능입문 듣기\n(100원/지능10이상)",font=("HY엽서체M", 16), command=buy_Grade)
    btn.pack()
    btn = Button(root,width=40,height=5,bg="grey", text="인공지능활용 듣기\n(250원/지능20이상)",font=("HY엽서체M", 16), command=buy_Grade3)
    btn.pack(pady=10)
    btn1 = Button(root,width=40,height=5,bg="grey", text="인공지능심화 듣기\n(700원/지능50이상)",font=("HY엽서체M", 16), command=buy_Grade10)
    btn1.pack(pady=10)
    textbtn = Button(root, width=40,height=5,bg="black",fg="green",text="나가기",command=close)
    textbtn.pack(side="bottom")
    root.mainloop()  
    return grade
# 퀴즈 게임 함수
def quiz_game():
    global sleep
    questions = {
        "많은 사람들이 일어나지 않은 거짓된 사실에 대한 기억을 공유하는 현상은 무엇인가요?": "만델라 효과",
        "국내 종합주가 지수로 대한민국의 주식 가격을 종합적으로 표시한 수치는 무엇인가요?": "코스피",
        "대한민국의 IMF 경제위기는 몇년도에 발생했을까요?": "1997",
        "오스트레일리아의 수도는 어디일까요?": "캔버라",
        "그리스 로마 신화에 나오는 지혜와 전술의 여신은 누구일까요?": "아테나",
        "자유의 여신상을 선물로 준 나라는 어디일까요?": "프랑스",
        "음악의 아버지는 바흐라면 의학의 아버지는 누구일까요?": "히포크라테스",
        "모든 혈액형에게 피를 수혈해줄 수 있는 혈액형은 무엇인가요?": "o형",
        "스승을 뛰어넘는 제자를 비유하는 사자성어는 무엇인가?": "청출어람",
        "한 시즌 동안 최고의 활약을 펼친 선수에게 수여하는 상으로, 축구 선수로서 받을 수 있는 가장 명예로운 상으로 여겨지는 이상은?": "발롱도르",
        "가장 많은 월드컵 우승을 차지한 국가는?": "브라질",
        "종이 위에 물감을 두껍게 칠하고 반으로 접거나 다른 종이를 덮어서 무늬를 만드는 이 기법은?": "데칼코마니",
        "현재 대한민국에서 가장 넓은 땅을 가지고 있는 도는 어디일까요?": "경상북도",
        "레오나르도 다빈치가 그린 최후의 만찬에서 예수를 포함하여 나오는 인물은 총 몇 명 일까요?":  "13명",
        "밀가루 반죽에 고기와 야채 등을 넣고 철판에서 구운 일본 오사카의 대표요리로, 한국의 빈대떡과 비슷한 이 음식은?": "오코노미야끼",
        "척추동물의 적혈구 속에 있는 색소 단백질로 혈액이 붉는것은 적혈구 속 이것의 색깔 때문이다. 이것은?": "헤모글로빈",
        "전 세계에서 가장 많은 언어로 번역된 책은?": "성경",
        "화폐가치가 하락하여 물가가 전반적 지속적으로 상승하는 경제적 현상은?": "인플레이션",
        "초음속 비행기가 내는 큰 소음이자 폭팔음이라고도 하며, 큰 에너지를 발생시킵니다. 이 용어는?": "소닉붐",
        "인도에서 직업에 따라 사람들을 구별하는 제도로 크게 네 개의 신분으로 나누는 이 신분제도는?": "카스트제도",
        "다양한 기관, 효소 , 호르몬 등 신체를 이루는 주 성분으로 몸에서 물 다음으로 많은 이것은?": "단백질",
        "금융시장이 불안정하거나 부실한 은행에 불안감을 느껴서 고객이 한꺼번에 돈을 찾아가는 대규모 예금인출사태인 이 용어는?": "뱅크런",
        "블랙홀도 에너지를 방출한다는 사실을 밝혀내는 등 우주를 이해하는데 많은 공헌을 했고 2018년에 사망한 이 사람은?": "스티브 호킹",
        "사고 또는 질환이 발생한 환자의 생명을 지키기 위해 의학적 조치가 행해져야 하는 제한 된 시간을 무엇이라 할까요?": "골든타임",
        "현대 물리학자들이 측정할 수 있는 가장 작은 입자는?": "쿼크",
        "부모의 유전정보를 담고 있는 이중나선 구조의 핵산으로, 유전자의 본체는?": "dna",
        "혈액 속의 혈당량을 조절하는 호르몬은?": "인슐린",
        "우주개발 및 지구탐사, 항공기 개발등의 전반적 업무를 담당하고 있는 미국의 국가기관은?": "nasa",
        "열대야로 규정짓는 최저온도는?": "25도",
        "프랑스 잔다르크가 활약하여 승리로 이끈 전쟁의 이름은?": "백년전쟁",
        "통신이나 인터넷을 통해 불특정 다수에게 대량으로 보내지는 광고성 메일은?": "스팸메일",
        "국악기 중 현악기, 두줄로 된 찰현악기로 깡깡이, 앵금 등의 이름으로도 불린 이 악기는?": "해금",
        "이성적인 사고를 통해 진리에 도달할 수 있다고 주장하며, 나는 생각한다, 고로 존재한다라는 명제를 남긴 근대 철학자는?": "데카르트",
        "공기 속에서 고속으로 움직이는 물체에 대해 음속을 기준으로 나타낸 속도의 단위는?": "마하",
        "원자 번호 6번으로, 모든 유기물의 기본이 되는 원소는 무엇인가?": "탄소",
        "세계 최초의 성공적인 백신은 어떤 질병을 예방하기 위해 개발되었을까요?": "천연두",
        "인류가 발견한 가장 오래된 문명은?": "메소포타미아 문명",
        "인류가 최초로 사용한 금속은?": "구리",
        "2000년-2020년 평균 전 세계 생산량이 가장 많은 곡물은?": "옥수수",
        "19세기 산업혁명을 촉발한 주요 에너지원은?": "석탄",
        "테니스 또는 골프에서 한 해동안 4개의 메이저대회에서 모두 우승하는 것을 일컫는 말은?": "그랜드슬램",
        }

    quiz_list = list(questions.items())
    random.shuffle(quiz_list)
    score = 0
    root = tk.Tk()
    root.withdraw()

    for i, (question, answer) in enumerate(quiz_list[:10], 1):
        user_input = simpledialog.askstring(f"퀴즈 {i}/10", question.strip())
        if user_input == answer:
            score += 1
    sleep = True
    root.destroy()
    return score

# 조준 게임 함수
def aim_game():
    tk.messagebox.showinfo("가이드","이게임은 마우스로 책을 클릭하는 게임입니다.")
    school_image = pygame.image.load("school.png")
    school_image = pygame.transform.scale(school_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
    mini_screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

    target_image = pygame.image.load("target.png")
    target_image = pygame.transform.scale(target_image, (60, 60))
    target_rect = target_image.get_rect()
    target_rect.topleft = (
        random.randint(0, SCREEN_WIDTH - target_rect.width),
        random.randint(0, SCREEN_HEIGHT - target_rect.height),
    )

    target_spawn_time = 2000
    last_spawn_time = pygame.time.get_ticks()
    score = 0
    game_time = 15
    start_time = pygame.time.get_ticks()

    running = True
    while running:
        elapsed_time = (pygame.time.get_ticks() - start_time) / 1000
        remaining_time = max(0, game_time - int(elapsed_time))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if target_rect.collidepoint(pygame.mouse.get_pos()):
                    button_click_sound.play()
                    score += 1
                    target_rect.topleft = (
                        random.randint(0, SCREEN_WIDTH - target_rect.width),
                        random.randint(0, SCREEN_HEIGHT - target_rect.height),
                    )

        if pygame.time.get_ticks() - last_spawn_time > target_spawn_time:
            target_rect.topleft = (
                random.randint(0, SCREEN_WIDTH - target_rect.width),
                random.randint(0, SCREEN_HEIGHT - target_rect.height),
            )
            last_spawn_time = pygame.time.get_ticks()

        mini_screen.blit(school_image, (0, 0))
        mini_screen.blit(target_image, target_rect.topleft)

        font = pygame.font.Font(None, 36)
        score_text = font.render(f"Score: {score}", True, (0, 255, 0))
        timer_text = font.render(f"Time Left: {remaining_time}", True, (125, 125, 50))
        mini_screen.blit(score_text, (10, 10))
        mini_screen.blit(timer_text, (10, 50))

        pygame.display.update()

        if remaining_time <= 0:
            running = False

    return score
def alba_game():
    global player_money

    tk.messagebox.showinfo("가이드", "이 게임은 키보드로 입력으로 이루어집니다.\nEx)Q입력은 패티,Patty\n \n켜진후의 잠시만 기다려주세요")   
    
    school_image = pygame.image.load("burger_inside.png")
    school_image = pygame.transform.scale(school_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
    mini_screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

    burger_current = 0
    burger_count = 0
    current_index = 0  # 현재 맞춰야 하는 재료의 인덱스
    burger_items = [
        (pygame.image.load("Patty.png"), "Patty"),
        (pygame.image.load("Sauce.png"), "Sauce"),
        (pygame.image.load("Lettuce.png"), "Lettuce"),
        (pygame.image.load("Cheese.png"), "Cheese"),
        (pygame.image.load("Pikle.png"), "Pikle"),
        (pygame.image.load("Onion.png"), "Onion")
    ]
    # 이미지 크기 조정
    for i in range(len(burger_items)):
        image, name = burger_items[i]
        scaled_image = pygame.transform.scale(image, (250, 250))
        burger_items[i] = (scaled_image, name)

    running = True
    while running:
        if current_index == 0:  # 새로운 버거 조합 시작
            current_burger_items = burger_items[:]  # 원본 리스트 복사
            random.shuffle(current_burger_items)  # 섞기

        current_image, current_name = current_burger_items[current_index]  # 현재 재료 가져오기

        #화면출력
        mini_screen.blit(school_image, (0, 0))
        mini_screen.blit(current_image, (SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT // 2 - 175))
        burger_text = font.render(f"Select: {current_name}", True, (255, 255, 255))
        mini_screen.blit(burger_text, (SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 + 100))
        control_text = font.render(f"Q:Patty  W:Sauce  E:Lettuce  R:Cheese  A:Pikle  S:Onion",True,(40,40,40))
        mini_screen.blit(control_text, (320 , 50))
        pygame.display.update()

        waiting_for_input = True
        while waiting_for_input:
            burger_made = None
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    # 키 입력에 따라 플레이어 선택
                    if event.key == pygame.K_q:
                        button_click_sound.play()
                        burger_made = "Patty"
                    elif event.key == pygame.K_w:
                        button_click_sound.play()
                        burger_made = "Sauce"
                    elif event.key == pygame.K_e:
                        button_click_sound.play()
                        burger_made = "Lettuce"
                    elif event.key == pygame.K_r:
                        button_click_sound.play()
                        burger_made = "Cheese"
                    elif event.key == pygame.K_a:
                        button_click_sound.play()
                        burger_made = "Pikle"
                    elif event.key == pygame.K_s:
                        button_click_sound.play()
                        burger_made = "Onion"
                    else:
                        tk.messagebox.showinfo("에러", "잘못된 입력입니다.")
                        continue

                    print(f"burger_made: {burger_made}, current_name: {current_name}")
                    # 입력 확인
                    if burger_made.strip().lower() == current_name.strip().lower():
                        current_index += 1  # 다음 재료로 넘어감
                        if current_index == 6:  # 모든 재료를 맞춘 경우
                            burger_current += 1
                            burger_count += 1
                            tk.messagebox.showinfo("완성", "햄버거 완성!")
                            current_index = 0  # 재료 인덱스 초기화
                        waiting_for_input = False  # 현재 입력 루프 종료
                    else:
                        burger_count += 1
                        tk.messagebox.showinfo("실패", "햄버거 실패.")
                        current_index = 0  # 틀리면 처음부터 다시 시작
                        waiting_for_input = False


        # 종료 조건
        if burger_count >= 5:  # 예: 5개의 버거를 완성하면 게임 종료
            player_money += burger_current * 80
            tk.messagebox.showinfo("버거",f"햄버거를 만든 개수:{burger_current}\n총 번돈:{burger_current*80}")
            running = False
#게임 오버
def game_over():
    global player_money
    global knowledge
    global grade

    def close():
        root.destroy()

    root = tk.Tk()

    beaksuimage = Image.open('beaksu.png')
    beaksu = ImageTk.PhotoImage(beaksuimage)

    secondimage = Image.open('second.png')
    second = ImageTk.PhotoImage(secondimage)

    thirdimage = Image.open('third.png')
    third = ImageTk.PhotoImage(thirdimage)

    forthimage = Image.open('forth.png')
    forth = ImageTk.PhotoImage(forthimage)

    fifthimage = Image.open('fifth.png')
    fifth = ImageTk.PhotoImage(fifthimage)

    grade_var = tk.StringVar()
    grade_var.set(f"학점: {grade}")
    if grade < 10:
        root.title("Last Score")
        root.geometry("480x680")
        root.resizable(False, False)
        imageLable = Label(root, image=beaksu)
        imageLable.pack(expand=1, anchor=CENTER)
        textLable = Label(root, width=40,fg="#2F4F4F",text="당신의 직업은 백수입니다.", font=("맑은 고딕", 16))
        textLable.pack()
        scoreLable = Label(root, width=40,height=3, fg="blue",textvariable=grade_var, font=20)
        scoreLable.pack()
        btn = Button(root,width=20,height=5,bg="green", text="확인", command=close, font=16)
        btn.pack()
    elif grade < 20:
        root.title("Last Score")
        root.geometry("480x680")
        root.resizable(False, False)
        imageLable = Label(root, image=second)
        imageLable.pack(expand=1, anchor=CENTER)
        textLable = Label(root, width=40,fg="#2F4F4F",text="당신의 직업은 알바입니다.", font=("맑은 고딕", 16))
        textLable.pack()
        scoreLable = Label(root, width=40, height=3,fg="blue",textvariable=grade_var, font=20)
        scoreLable.pack()
        btn = Button(root,width=20,height=5,bg="green", text="확인", command=close, font=16)
        btn.pack()
    elif grade < 30:
        root.title("Last Score")
        root.geometry("480x680")
        root.resizable(False, False)
        imageLable = Label(root, image=third)
        imageLable.pack(expand=1, anchor=CENTER)
        textLable = Label(root, width=40,fg="#2F4F4F",text="당신의 직업은 사무보조입니다.", font=("맑은 고딕", 16))
        textLable.pack()
        scoreLable = Label(root, width=40, height=3,fg="blue",textvariable=grade_var, font=20)
        scoreLable.pack()
        btn = Button(root,width=20,height=5,bg="green", text="확인", command=close, font=16)
        btn.pack()
    elif grade < 40:
        root.title("Last Score")
        root.geometry("480x680")
        root.resizable(False, False)
        imageLable = Label(root, image=forth)
        imageLable.pack(expand=1, anchor=CENTER)
        textLable = Label(root, width=40,fg="#2F4F4F",text="당신의 직업은 프로그래머입니다.", font=("맑은 고딕", 16))
        textLable.pack()
        scoreLable = Label(root, width=40, height=3,fg="blue",textvariable=grade_var, font=20)
        scoreLable.pack()
        btn = Button(root,width=20,height=5,bg="green", text="확인", command=close, font=16)
        btn.pack()
    elif grade < 100:
        root.title("Last Score")
        root.geometry("480x680")
        root.resizable(False, False)
        imageLable = Label(root, image=fifth)
        imageLable.pack(expand=1, anchor=CENTER)
        textLable = Label(root, width=40,fg="#2F4F4F",text="당신의 직업은 IT기업의 사장님입니다!\n대단하시군요!",font=("맑은 고딕", 16))
        textLable.pack()
        scoreLable = Label(root, width=40, height=3,fg="blue",textvariable=grade_var, font=20)
        scoreLable.pack()
        btn = Button(root,width=20,height=5,bg="green", text="확인", command=close, font=16)
        btn.pack()

    root.mainloop()
# 메인 함수
def main():
    global player_money
    global knowledge
    global sleep
    global grade
    global shift_pressed
    player = Animated(position=(100, screen_image_y))
    all_sprites = pygame.sprite.Group(player)

    reset_image = pygame.image.load("reset.png")
    reset_image = pygame.transform.scale(reset_image, (100, 100))
    reset_rect = reset_image.get_rect(topleft=(50, screen_image_y-25))

    quiz_image = pygame.image.load("quiz.png")
    quiz_image = pygame.transform.scale(quiz_image, (100, 100))
    quiz_rect = quiz_image.get_rect(topleft=(800, screen_image_y-25))

    shot_image = pygame.image.load("bus.png")
    shot_image = pygame.transform.scale(shot_image, (250, 100))
    shot_rect = shot_image.get_rect(topleft=(450, screen_image_y-25))

    shop_image = pygame.image.load("shop.png")
    shop_image = pygame.transform.scale(shop_image, (100, 100))
    shop_rect = shop_image.get_rect(topleft=(250, screen_image_y-25))

    burger_image = pygame.image.load("burger_shop.png")
    burger_image = pygame.transform.scale(burger_image, (100, 100))
    burger_rect = burger_image.get_rect(topleft=(1000, screen_image_y-25))

    #게임시간(초)
    timer_duration = 600
    start_ticks = pygame.time.get_ticks()
    pause_ticks = 0

    running = True
    while running:
        mt = clock.tick(FPS) / 1000

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    player.direction = "right"
                elif event.key == pygame.K_LEFT:
                    player.direction = "left"
                elif player.rect.colliderect(quiz_rect) and event.key == pygame.K_y:
                    if sleep == False:
                        paused_start = pygame.time.get_ticks()
                        score = quiz_game()
                        pause_ticks += pygame.time.get_ticks() - paused_start
                        knowledge += score
                        sleep = True
                    elif sleep == True:
                        tk.messagebox.showinfo("수면", "수면이 필요합니다.")
                elif player.rect.colliderect(reset_rect) and event.key == pygame.K_y:
                    if sleep == True:
                        tk.messagebox.showinfo("용돈","하루가 지났습니다.\n(+$100,-01:00 )")
                        player_money += 100
                        start_ticks -= 60000
                        sleep = False
                    elif sleep == False:
                        tk.messagebox.showinfo("수면","아직 할일을 끝내지 않았습니다.")
                elif player.rect.colliderect(shot_rect) and event.key == pygame.K_y:
                    if knowledge >= 5 and not sleep:
                        paused_start = pygame.time.get_ticks()
                        knowledge += aim_game()  # 미니게임 실행
                        pause_ticks += pygame.time.get_ticks() - paused_start
                        sleep = True
                    elif knowledge < 5:
                        tk.messagebox.showinfo("부족", "지식이 부족합니다. \n(필요 지식: 5)")
                    elif sleep == True:
                        tk.messagebox.showinfo("수면", "수면이 필요합니다.")
                elif player.rect.colliderect(shop_rect) and event.key == pygame.K_y:
                    game_shop()
                elif player.rect.colliderect(burger_rect) and event.key == pygame.K_y:
                    if sleep == False:
                        paused_start = pygame.time.get_ticks()
                        alba_game()
                        pause_ticks += pygame.time.get_ticks() - paused_start
                        sleep = True
                    elif sleep == True:
                        tk.messagebox.showinfo("수면", "수면이 필요합니다.")
            elif event.type == pygame.KEYUP:
                if event.key in [pygame.K_RIGHT, pygame.K_LEFT]:
                    player.direction = "front"
                    player.speed_x = 0

        all_sprites.update(mt)
        elapsed_seconds = (pygame.time.get_ticks() - start_ticks - pause_ticks) / 1000
        remaining_time = max(0, timer_duration - int(elapsed_seconds))
        if remaining_time > 0:
            timer_text = font.render(f"Time Left: {remaining_time // 60}:{remaining_time % 60:02}", True, (70, 80, 90))
        else:
            game_over()
            tk.messagebox.showinfo("게임종료","게임이 종료되었습니다.")
            end_text = font.render("Time Over", True, (255, 0, 0))
            SCREEN.blit(end_text, (SCREEN_WIDTH / 2 - end_text.get_width() // 2, SCREEN_HEIGHT / 2 - end_text.get_height() // 2))
            pygame.display.update()
            pygame.time.delay(2000)
            pygame.quit()
            sys.exit()

        SCREEN.blit(screen_image, (0, 0))
        SCREEN.blit(quiz_image, quiz_rect.topleft)
        SCREEN.blit(reset_image, reset_rect.topleft)
        SCREEN.blit(shot_image, shot_rect.topleft)
        SCREEN.blit(shop_image, shop_rect.topleft)
        SCREEN.blit(burger_image, burger_rect.topleft)

        if player.rect.colliderect(quiz_rect):
            quiz_text = font.render("Press Y to start the quiz game.", True, (50, 50, 50))
            SCREEN.blit(quiz_text, (SCREEN_WIDTH // 2 - quiz_text.get_width() // 2, SCREEN_HEIGHT // 2 + 50))

        if player.rect.colliderect(reset_rect):
            reset_text = font.render("Press Y to go sleep.", True, (50, 50, 50))
            SCREEN.blit(reset_text, (SCREEN_WIDTH // 2 - reset_text.get_width() // 2, SCREEN_HEIGHT // 2 + 50))

        if player.rect.colliderect(shot_rect):
            shot_text = font.render("Press Y to go school.", True, (50, 50, 50))
            SCREEN.blit(shot_text, (SCREEN_WIDTH // 2 - shot_text.get_width() // 2, SCREEN_HEIGHT // 2 + 50))

        if player.rect.colliderect(shop_rect):
            shop_text = font.render("Press Y to go shop.", True, (50, 50, 50))
            SCREEN.blit(shop_text, (SCREEN_WIDTH // 2 - shop_text.get_width() // 2, SCREEN_HEIGHT // 2 + 50))
        
        if player.rect.colliderect(burger_rect):
            burger_text = font.render("Press Y to work burger store.", True, (50, 50, 50))
            SCREEN.blit(shop_text, (SCREEN_WIDTH // 2 - burger_text.get_width() // 2, SCREEN_HEIGHT // 2 + 50))

        money_text = font.render(f"Money: ${player_money}", True, (255, 161, 92))
        SCREEN.blit(money_text, (10, 10))

        knowledge_text = font.render(f"Knowledge: {knowledge}", True, (137, 178, 233))
        SCREEN.blit(knowledge_text, (170, 10))
        #잠 상태 출력

        if sleep == True:
            sleep_text = font.render("Sleep: O", True, (0, 255, 255))  
        else:
            sleep_text = font.render("Sleep: X", True, (205, 92, 92))

        SCREEN.blit(sleep_text, (10, 50))

        # 학점 출력

        grade_text = font.render(f"grade: {grade}", True, (46,139,87))
        SCREEN.blit(grade_text, (640, 10))
        all_sprites.draw(SCREEN)
        SCREEN.blit(timer_text, (SCREEN_WIDTH - 200, 20))
    
        pygame.display.update()
if __name__ == '__main__':
    main()        
